
                                Scan320

                      Version 1.1 - October, 2001

Tom Lackamp
tom2000@mindspring.com
http://www.qsl.net/ab9b


Overview

This program is my freeware controller for the TenTec RX-320 shortwave
radio.

The program runs on all 32-bit Windows operating systems, except Windows XP.

Scan320 provides comprehensive tuning and scanning, and is fully
compatible with my tuner/browser for the ILGRadio Shortwave Database,
Scan320DB, and is data compatible with my freeware logging program,
B-Log.

Refer to the Scan320Help.html document included with the distribution
archive for a full feature description.


Installation and Removal 

If you plan to install Scan320DB and/or B-Log, you may place all three programs 
in the same working directory.

If you will not be installing Scan320 along with an existing Scan320DB and/or 
B-Log installation, create a working directory for Scan320. Unzip the 
distribution archive into your new working directory. 

Verify that your unzipper has installed Scan320.exe, Scan320-Readme.txt,
and Alarm.wav in the working directory, Scan320's help file and illustrations in the Help
subdirectory, and B-Log's help file and illustrations in the LogHelp subdirectory.

If you are installing Scan320 with Scan320B and/or B-Log, unzip the archive 
into the working directory you use for those programs. Let your unzipper overwrite 
the help file and illustrations currently installed in your LogHelp subdirectory. 
Verify that your unzipper has installed Scan320's help file and illustrations 
into the Help subdirectory.

Create a desktop icon for Scan320. 

Start the program. If this is a new installation, it will create a subdirectory 
tree under the working directory. 


Removing Scan320 

Scan320 doesn't install any DLL's or write anything to your registry. If you wish 
to remove the program, delete Scan320.exe from your working directory and delete 
your desktop icon. If you haven't installed Scan320DB or B-Log, you can delete your 
entire working directory and all its subdirectories. 

